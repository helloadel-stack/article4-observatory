Bouclier IA Publique (Safe Public AI Shield / Escudo IA Publica)
Institut Article 4 (A4I) — Programme non-lucratif pro bono — CC BY-NC 4.0

Ce kit n'est PAS un logiciel open source OSI. Il est publie sous licence
non commerciale CC BY-NC 4.0 pour le secteur public et educatif.

Module 1 — Diagnostic Shadow AI & Charte (Art. 4)
  01-matrice-shadow-ai.xlsx
  01-charte-usage-institutionnelle.docx
  01-plan-sensibilisation-dgs-dsi-dpo.pdf

Module 2 — Boussole du Risque IA & Clause marches publics
  02-boussole-risque-ia.xlsx
  02-clause-type-ccap-ia.docx
  02-grille-evaluation-fournisseurs.pdf

Module 3 — Registre & Transparence algorithmique (Art. 50)
  03-registre-modeles-prompts.xlsx
  03-protocoles-supervision-humaine.docx
  03-formulaire-signalement-incident.pdf

Module 4 — Scorecard executif & feuille de route
  04-scorecard-maturite-ia-publique.pdf
  04-roadmap-strategique-6-12-mois.docx
  04-guide-structuration-comite-ia.pdf

Alignement: DINUM/CNIL + France Universites/CGE + ISO/IEC 42001 (FR),
APD (BE), nLPD/PFPDT (CH), Loi 25 + OBVIA (Quebec).
Attestation: https://article4institute.org/bouclier-public#scorecard
Verification: https://waqfledger.tech/verify
Observatoire: https://article4institute.org#observatory