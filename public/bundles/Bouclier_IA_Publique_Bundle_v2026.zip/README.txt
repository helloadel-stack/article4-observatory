Bouclier IA Publique (Safe Public AI Shield)
Institut Article 4 (A4I) — Programme non-lucratif & open source (CC BY-NC 4.0)

Contenu du package:
1. 01-diagnostic-shadow-ai-charte.docx
2. 02-boussole-risque-ia-clause-ccap.xlsx
3. 03-registre-transparence-art50.pdf
4. 04-scorecard-executif-feuille-de-route.pdf

Alignement: DINUM/CNIL (FR), APD (BE), nLPD/PFPDT (CH)
Verification attestations: https://waqfledger.tech